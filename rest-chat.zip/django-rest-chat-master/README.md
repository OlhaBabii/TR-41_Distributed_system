# django-rest-chat

This is simple one-to-one django+rest chat (html+css)

Activate:

* Install virtualenv
```
virtualenv venv
source ./venv/bin/activate
```

* Migrate BD
```
python manage.py migrate
```

* Run server
```
python manage.py runserver
```

Open in browser /localhost and enjoy
